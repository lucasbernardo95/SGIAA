package dao;

import java.util.List;
import model.Usuario;


/**
 *
 * @author lber
 */
public class UsuarioDAO extends GenericDAO<Usuario>{

}
