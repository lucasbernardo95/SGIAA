package dao;

import model.Bairro;

/**
 *
 * @author lber
 */
public class BairroDAO extends GenericDAO<Bairro>{
    
}
